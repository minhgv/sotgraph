import json
from pathlib import Path
from sot_graph.db import Database
from sot_graph.reconciler import Reconciler
base=Path(__file__).resolve().parent
case=json.loads((base/'ts-closure-collision.json').read_text())
root=base/'ts-collision-repro'; root.mkdir(exist_ok=True)
(root/'stage.ts').write_text(case['source'])
db=Database(str(root/'.sot/sot.db')); Reconciler(db,str(root)).reconcile(workers=1)
print([tuple(x) for x in db.conn.execute("SELECT symbol FROM graph_nodes WHERE kind!='file'")])
print([tuple(x) for x in db.conn.execute("SELECT s.symbol,t.symbol,e.line FROM graph_edges e JOIN graph_nodes s ON e.src=s.id JOIN graph_nodes t ON e.dst=t.id WHERE e.relation='calls'")])
db.close()
