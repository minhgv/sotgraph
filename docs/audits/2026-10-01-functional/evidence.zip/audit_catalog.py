FEATURES = [
('F01','Cài đặt cấu hình và tích hợp harness','cli.build_parser, config.load_config, adapters.installer','config_loader,cli_smoke,repository_identity,completion_surface_packaging,p3_adapters,omp_integration,adapter_docs_consistency',
 'Wheel và sdist chạy CLI đúng version; thứ tự config defaults rồi TOML rồi env rồi override; setup lặp lại không làm hỏng nội dung người dùng.', '''
Cài wheel trong môi trường sạch|CLI đúng version và package data đầy đủ
Cài sdist trong môi trường sạch|Build và import không cần source checkout
Python tối thiểu và tối đa được hỗ trợ|Cùng contract trên Python 3.10 tới 3.14
Thiếu dependency tùy chọn|Lệnh core chạy và tính năng thiếu extra báo cách cài
Root chứa khoảng trắng hoặc Unicode|Không lỗi quoting hay encoding
TOML sai cú pháp|Lỗi có cấu trúc và exit khác 0 không traceback
TOML sai kiểu hoặc giá trị enum|Chỉ rõ key sai và không crash
Env mâu thuẫn TOML|Thực hiện đúng precedence và không mở external ngoài ý muốn
Setup hai lần cùng harness|Idempotent và bảo toàn custom text
Setup workspace only|Không ghi vào home hay workspace khác
Root hoặc file cấu hình là symlink|Canonical root và kiểm tra quyền nhất quán
Launcher bin dùng Python khác venv|Chạy interpreter có đúng dependency hoặc báo rõ
'''),
('F02','Trích xuất và lập chỉ mục đa ngôn ngữ','reconciler.Reconciler, extractor, ts_extract, db.Database._resolve_pending_edges_pass','sot_graph,multilang,treesitter,group1_extractors,group2_extractors,dart_extractor,c_cpp_extractor,java_extractor,php_extractor,python_resolver,python_scope_extended,python_semantic_resolver,lambda_comprehension_coverage,parallel_reconciler,force_reindex',
 'Định nghĩa và cạnh đúng identity và span; parse lỗi không giữ cạnh xác nhận sai; reconcile incremental tương đương rebuild.', '''
Repo rỗng không có file code|Reconcile thành công với zero counts
File có syntax error hoặc parse partial|Công bố parse failure và không giả complete
File rất lớn hoặc hàng cực dài|Bộ nhớ có giới hạn và không treo
File encoding sai hoặc binary giả source|Báo phân loại lỗi và không crash toàn batch
Nested function hoặc closure TypeScript|Owner cạnh là scope đúng
Import alias hoặc static import Java và Rust|Nối đúng identity hoặc để unresolved
Self receiver và trait method Rust|Không bỏ sót cạnh có thể chứng minh
Python lambda comprehension và shadowing|Binding không rò sang scope khác
Virtual dispatch reflection hoặc function pointer|Abstain khi không chứng minh được receiver
Thêm sửa xóa và đổi tên file|Không ghost node hoặc orphan edge
File đổi khi worker đang parse|CAS ngăn publication snapshot cũ
Workers chạy nối tiếp và song song|Cùng graph và metadata accounting
'''),
('F03','Tìm kiếm xếp hạng và trust axes','cli.cmd_search, db.Database.search_fts, verifier.TrustVerifier','search_bare_name_ranking,p4_search_safety,p4_ranking,trust_axes,trust_v2_evidence,truthfulness,verifier,precision_and_metamorphic,vector',
 'Search trả anchor xác minh trên disk; identity trùng phải ambiguous; ranking và giới hạn đầu ra nhất quán giữa CLI và MCP.', '''
Query trống hoặc toàn whitespace|Trả danh sách rỗng nhất quán
Query chứa quote NEAR dấu sao hoặc SQL text|Không lỗi FTS và không SQL injection
Symbol và đường dẫn tiếng Việt|Tìm đúng và giữ Unicode
Bare name trùng nhiều module|Axis identity ambiguous không giả compiler exact
Path qualified hoặc semantic query|Xếp đúng target theo corpus kiểm chứng
Scope chứa phần trăm underscore hoặc backslash|Match literal không mở rộng wildcard
Scope path giống từ trong body|Công bố scope là substring hay directory rõ ràng
Limit bằng 0 âm hoặc quá lớn|Validate hoặc clamp theo contract công khai
Threshold NaN Infinity hoặc ngoài khoảng|Từ chối finite domain không trả thành công âm thầm
Anchor đã xóa hoặc chuyển vị trí|Removed không được viện dẫn rebuilt dùng path mới
Hybrid vector chưa embed hoặc thiếu extra|Fallback có cấu trúc và JSON vẫn parse được
Top k cắt candidate đúng target|Công bố bounded retrieval và không khẳng định absence toàn repo
'''),
('F04','JIT freshness và tự phục hồi','freshness.ensure_fresh, freshness.staleness_probe, engine_daemon','jit_freshness,jit_reconcile,p0_freshness_semantics,reconcile_audit_receipts,snapshot_content_binding,snapshot_content_binding',
 'Gated query phải thấy nội dung mới hoặc công bố stale; async fast tier và deep tier phải giữ snapshot nhất quán.', '''
Index fresh|Không reconcile hoặc spawn không cần thiết
Sửa file giữa hai query|Anchor mới xuất hiện với freshness đúng
Thêm file chưa journal|Scan walk phát hiện và index
Xóa file đã index|Không phục vụ engine ghost như fresh
Mode off|Không heal và công bố stale khi cần
Mode force|Reconcile blocking kể cả index fresh
Mode auto async|Fast tier và deep tier công bố serving state
DB bị lock hoặc parse failure khi heal|Công bố failed và stale không giả fresh
Background spawn thất bại|Query vẫn trả lời với lý do thiếu refresh
PID chết hoặc lock stale|Dọn lock đúng owner không đè process sống
Sửa cùng size trong cùng millisecond|Hash assurance bắt drift hoặc yêu cầu explicit reconcile
Đổi branch hoặc delta vượt fast tier cap|Deep reconcile và snapshot invalidation đúng
'''),
('F05','Truy vết usages và kế thừa','cli.cmd_explore, cli.cmd_usages, db.Database.usages, inheritance_edges','navigation,edge_lifecycle,import_resolution,scoped_identity,p4_identity,p3_builtin_recall,wrong_edge_corpus',
 'Calls imports extends implements truy được hai chiều; unknown và ambiguous không chọn ngẫu nhiên; rename giữ đúng bản chất report only.', '''
Đồ thị có cycle tự gọi hoặc recursion|BFS hữu hạn không duplicate mất kiểm soát
Depth bằng 0 âm hoặc rất lớn|Validate resource budget
Symbol không tồn tại|Lỗi hoặc absence bounded rõ ràng
Bare name ambiguous|Không chọn candidate đầu tiên âm thầm
Call ở nhiều dòng cùng caller|Công bố chính xác nếu graph collapse call sites
Import và re export xuyên module|Identity và relation đúng
Kế thừa nhiều lớp interface abstract|Trả base và derived đúng direction
Caller vừa là test vừa là production name|Phân loại theo path và không suy từ bare name
File rename làm đổi FQN|Định vị anchor mới và không ghost usages
Edge pending unresolved hoặc ambiguous|Tách khỏi confirmed callers
Rename plan|Không ghi code và definition trỏ đúng line
Cạnh compiler và heuristic mâu thuẫn|Giữ provenance và công bố conflict
'''),
('F06','Context pack và giới hạn tài nguyên','pack.build_bundle, pack.render_yaml, cli.cmd_pack','sg202_pack_completeness,pack_sg202_priority,pack_target_recovery,sg202_target_recovery,sg202_pack_completeness,sg202_pack_completeness,sprint4_compass_and_pack',
 'Payload giữ identity target và contract quan trọng; số token thực không vượt budget; mọi omission do budget phải đồng bộ truncated completeness accounting.', '''
Target unique và budget rộng|Complete chỉ trong capability đã đo
Target không tồn tại hoặc path line sai|Lỗi có candidates và JSON parse được
Bare name ambiguous hòa điểm|Fail closed hoặc công bố dominant selection
Target disk stale khi reconcile off|STALE_SNAPSHOT có cấu trúc
Tokens dưới metadata floor|BUDGET_TOO_SMALL và không output thành công
Tokens ngay trên dưới boundary|Serialized token count đúng và completeness đổi đúng
Node cap cắt caller hoặc callee|Truncated true và completeness partial
Hops nodes hoặc bytes âm|Từ chối invalid_argument trên CLI và MCP
Source quá lớn vượt read cap|Giới hạn bộ nhớ và công bố missing span
Caller test cạnh tranh với callee contract|Giữ reserved test và contract theo priority
Byte cap dưới metadata floor|Công bố best effort và không nhầm strict token cap
Root là symlink hoặc var private var alias|Relative path nằm trong canonical project không chứa traversal
'''),
('F07','Repo map và scope','repo_map.build_repo_map, repo_map.pagerank, classify_path','repo_map,sg201_repo_map_filters,sg201_external_corpus,sg201_sg202_exit_gates',
 'Map ưu tiên production và công bố phần bị loại; focus và PageRank không vượt budget hoặc suy absence ngoài index.', '''
Repo chưa index hoặc rỗng|Thông báo empty không gợi reconcile vô hạn
Graph không có edge|PageRank hữu hạn và thứ tự deterministic
Graph cycle hoặc hub rất lớn|Runtime và memory có budget
Focus không tồn tại|Fallback được công bố
Focus nhiều symbol và path|Phạm vi deterministic
Tokens bằng 0 âm hoặc rất nhỏ|Reject hoặc công bố metadata floor
Production test fixture vendor generated docs tooling|Không contamination mặc định
Include category không hợp lệ|Lỗi rõ không âm thầm widening
Symbol trùng ở production và test|Production ordering đúng theo path
Scope alias hoặc path ngoài root|Canonical root và ngăn escape
Map bị cắt giữa dòng Unicode|Không hỏng output và báo truncated
Map không chứa symbol có trong repo|Không suy absence repo từ selection
'''),
('F08','Import SCIP và compiler provenance','importer.scip.ScipImporter, providers.scip.ScipProvider, translate_scip_range','scip_provider,scip_truncation,p3_scip_binding,import_resolution,identity_join',
 'Compiler evidence chỉ exact khi symbol range root và snapshot đều được kiểm chứng; malformed import không publish partial như complete.', '''
SCIP JSON hợp lệ|Import definition reference và provenance đúng
SCIP protobuf hợp lệ|Tương đương JSON trên cùng index
Varint bị cắt hoặc message size sai|Fail closed không publish partial
Thiếu hoặc không đọc được file index|Lỗi rõ và không crash
Range 3 hoặc 4 phần tử và UTF16 columns|Chuyển line column đúng
Path absolute traversal hoặc symlink escape|Không nhập evidence từ repo khác
Definition và reference cùng symbol|Roles không bị đảo
Symbol grammar escaped hoặc local symbol|Parser giữ canonical identity
File đã đổi sau lúc tạo compiler index|Snapshot mismatch không giả exact
Import cùng artifact nhiều lần|Idempotent và provider run có lineage
Compiler identity trùng bare name|Không gộp vì tên giống
Provider SCIP thiếu capability impact|Require impact fail closed
'''),
('F09','Provider federation và managed engine','providers_registry, providers.codebase_memory, providers.managed, cbm.reconcile_dispatch','providers_registry,provider_contract,provider_compatibility,cbm_adapter,cbm_store,cbm_exact_compatibility,cbm_managed_provider,managed_transport,managed_execution,managed_read_dispatch,trusted_managed_config,cbm_snapshot_p2',
 'Registry capability policy chính xác; fallback disclosed; store và ledger bound canonical root snapshot version.', '''
External tắt mặc định|Không spawn provider bất ngờ
Require provider không cài|Fail closed và error có cấu trúc
Auto provider chết hoặc timeout|Fallback bounded có lý do
Provider version không tương thích|Không giả supported hoặc compiler exact
Config command không trusted|Không thực thi ngoài trust policy
PATH shadowing hoặc command argument injection|Resolved binary provenance đúng
Engine JSON malformed hoặc stream vượt cap|Reject hoặc truncate honest
Snapshot SHA manifest generation mismatch|Không bind evidence cũ vào query mới
Nhiều repo chung engine store|Không leakage project binding
Builtin fast tier cạnh tranh engine snapshot|Newest wins theo ownership đúng
Native socket path quá dài và daemon restart|Fallback không làm hỏng index
CBM thật và index SCIP trong luồng end to end|Usages ledger và receipt semantic assertions đúng
'''),
('F10','Assurance receipt và lineage','assurance.receipts, assurance.state, assurance.impact_pipeline, receipt_explorer','p7_receipts,mcp_receipt_tools,p7_receipts,scope_receipt_multi,scope_receipt_recovery,lineage_chain,p6_ledger,assurance_state,coverage_manifest,collection_accounting,sg205_receipt_explorer',
 'Sáu trạng thái assurance nhất quán; digest bind scope snapshot và evidence; không nâng confidence khi thiếu coverage hoặc bị cắt.', '''
Scope unique fresh covered|Assured chỉ within scope
Scope missing ambiguous hoặc partial targets|Không nâng thành assured
Thay đổi HEAD giữa pre và post receipt|Lineage mismatch được báo
Receipt digest sửa tay hoặc schema tương lai|Reject tampering hoặc unsupported version
Receipt path không tồn tại|Error có cấu trúc không traceback
Symlink retarget hoặc repo root khác|Không join cross root
Coverage chưa đo hoặc parse failures|UNVERIFIABLE hoặc PARTIAL đúng rule
Response bị trim do resource cap|Degrade assurance cùng collection stats
Unjournaled file hoặc unsupported grammar|Enumeration incomplete công bố
Ledger conflict hoặc stale provider run|CONFLICTED hoặc STALE đúng rule
Store receipt thất bại do disk lock|Không báo đã lưu thành công
Receipt show diff chain thiếu predecessor|Bounded recovery và không hallucinate lineage
'''),
('F11','Diff impact lịch sử và safe commit','diff_impact.GitDeltaExtractor, DiffImpactEngine, CommitHistoryEngine, assurance.resolution','diff_impact,diff_impact_github,impact_pipeline,semantic_breaks,test_impact_split,safe_commit_gate,commit_verdict,resolution_ledger,precommit_gate,history_retention',
 'Changed lines map đúng node; reverse traversal đúng tests/API; git failure và missing evidence không biến thành báo cáo an toàn.', '''
Sửa body và signature API|Map đúng hunk và breaking change
Rename hoặc delete file symbol|Giữ tác động theo pre change coordinates
Staged unstaged và untracked|Chọn đúng diff universe
Repo không Git hoặc ref không tồn tại|Collection error rõ thay vì LOW risk rỗng
Root commit không có parent|Git show fallback hợp lệ không false error
Filename quote tab newline backslash Unicode|Parse Git C quoting hoặc NUL đúng
Binary mode only và submodule changes|Công bố unmapped artifact
Depth cap và graph cycle|Bounded traversal và omission rõ
Test shaped callers và fixture code|Candidate tests khác production impact
Getattr args kwargs re export và non Python semantic breaks|Công bố blind spots không khẳng định no break
Caller supplied test report giả provenance|Không coi như verified execution
Gate timeout SIGALRM hoặc Windows no SIGALRM|Policy advisory strict được công bố và fail closed khi yêu cầu
'''),
('F12','MCP transport profile và parity','mcp_server.create_server, mcp_service.McpService, sanitize_transport_value','mcp,mcp_modern,mcp_profiles,mcp_prompts,mcp_receipt_tools,managed_policy_parity,accounting_contract',
 'Discovery và dispatch cùng allowlist; startup và lỗi có cấu trúc; response cap và parity với CLI giữ trust semantics.', '''
Handshake qua process stdio thật|Version và tools list đúng
Profiles core full ops|Allowlist lần lượt đúng không widen âm thầm
Gọi hidden writer trực tiếp bằng RPC|tool_disabled dù client không discovery
Profile env sai và flag override|Reject invalid profile đúng precedence
Argument unknown bool float âm NaN|Schema validation và service bounds nhất quán
Output directory traversal hoặc symlink|Không ghi ngoài project
Response vượt byte cap hoặc một record quá lớn|Trim đúng collection stats và assurance
Invalid UTF8 surrogate control chars|Transport JSON hợp lệ
Request concurrent và client disconnect|Không leak writer connection hoặc lock
Freshness reconcile thất bại|Envelope serving state công bố
Pack node cap trên CLI và MCP|Cả hai công bố partial nếu có omission
SDK extra chưa cài|CLI core import chạy MCP báo hướng dẫn
'''),
('F13','SQLite bảo trì và ghi chú bền vững','db.Database.integrity_check, plan_clean, apply_clean, cli.cmd_insert','storage_integrity,maintenance,p9_chaos_migration,v2_upgrade,history_retention,core_safety_fixes,hardening_fixes',
 'Atomic publication và WAL bảo toàn dữ liệu; schema FTS thống nhất; clean all bảo toàn notes trừ khi explicitly include notes.', '''
Database file bị corrupt hoặc không SQLite|Doctor chẩn đoán có cấu trúc không traceback
Schema cũ hoặc migration fail|Notes giữ nguyên và rebuild được công bố
FTS mismatch orphan node hoặc foreign key violation|Doctor báo lỗi không tự sửa trong read only
Clean stale file và dangling edge|Không xóa notes hợp lệ
Clean all không include notes|Bảo toàn notes vĩnh viễn
Clean all include notes|Chỉ xóa notes khi explicit scope
Dry run clean và vacuum|Không thay đổi dữ liệu
WAL hard kill giữa transaction|Recovery không mixed generations
ENOSPC hoặc connection drop|Rollback và không half published graph
Concurrent reader writer|Không incoherent snapshot
Lock timeout replace hoặc unlink lock|Không release lock thuộc owner khác
Database read only hoặc directory permission denied|Graceful actionable error và không implicit relocation
'''),
('F14','Watcher process và concurrency','watcher.run_watch, start_daemon, stop_daemon, proc.run_command, engine_daemon','watcher_daemon,engine_daemon,proc_runner,proc_environment,proc_process_group,proc_streaming_cap,proc_windows_job,proc_windows_job,monorepo_ledger_concurrency,fault/test_fault_injection,property/test_invariants',
 'Watcher fold event đúng; stop theo process identity; subprocess timeout output cap và kill group không làm hại process khác.', '''
Watcher chưa chạy và status request|Exit contract STOPPED rõ
Create modify rename delete burst|Debounce không làm mất sự kiện
File bị ignore và dot directory|Không reconcile out of scope
Watchfiles chưa cài|Poll fallback tương đương
LockBusy khi batch reconcile|Queue retry không mất path
Daemon start hai lần đồng thời|Chỉ một verified identity owner
PID reuse hoặc stale PID file|Không kill process unrelated
Symlink repo hoặc multi project watcher|Canonical project isolation
SIGINT SIGTERM và child grandchild|Đóng group và giải phóng resources
Output quá lớn hoặc child ghi liên tục|Streaming cap không deadlock
Timeout spawn error và env secrets|Exit normalized và env không rò dữ liệu
Windows Job Object và macOS LaunchAgent systemd|Kiểm chứng riêng trên đúng OS không suy từ mocks
'''),
('F15','Trace analytics bundle và export','trace.trace_fullstack, solution.generate_solution_bundle, analytics.bundle, export','solution_trace,bundle,bundle_conformance,report_conformance,analytics,arch_flow,arch_module,arch_html,export,arch_flow',
 'Artifact đọc được và scope honest; facts không thành kiến trúc chắc chắn khi heuristic; export escape metadata và deterministic.', '''
Bundle facts|Sinh đúng 5 fact files có schema và scope
Graph rỗng hoặc không có edge|Analytics hữu hạn không division by zero
Hub nhiều node hoặc hàng chục nghìn node|Runtime memory budget và progress cancellation
Trace endpoint symbol ticket không tồn tại|Bounded absence và không dựng đường giả
UI branch API binding từ regex body|Gắn heuristic không giả runtime flow
Solution inventory và steps|Role effort chỉ đề xuất heuristic không giả chứng minh
Architecture flow target không tồn tại|Exit 2 và không ghi HTML giả
HTML metadata chứa script quote hoặc closing tag|Escape XSS và JSON an toàn
GraphML JSON GraphRAG SCIP export|Output parse được và đúng relation identity
Obsidian filename collision Unicode reserved names|Không overwrite và link đúng
Scope tests hoặc repo path filter|Facts và export dùng đúng universe
Các bước integration dùng root checkout thật|Fixture temp root timeout không tạo artifact ngoài audit
'''),
]

PROBE_MAP = {
 'F01-01':'wheel-smoke.log', 'F01-02':'sdist-smoke.log', 'F01-06':'config-invalid-toml',
 'F01-07':'config-invalid-type', 'F01-09':'setup-idempotent','F01-10':'setup-workspace-omp',
 'F02-01':'empty-reconcile','F02-05':'ts-closure-collision.json','F02-06':'oracle.json:builtin.confusion','F02-07':'oracle.json:builtin.confusion','F02-09':'oracle-inspection.json:python',
 'F03-01':'functional-probes.json:search-robust whitespace','F03-02':'functional-probes.json:search-robust SQL text','F03-03':'search-unicode','F03-04':'search-ambiguous-axes',
 'F03-08':'search-invalid-limit--1','F03-09':'search-invalid-threshold-nan',
 'F04-02':'jit-freshness-recovery','F04-03':'jit-new-file','F04-04':'jit-deleted-file','F04-06':'jit-freshness-recovery',
 'F05-03':'missing-target-explore','F05-07':'implementations-inheritance','F05-11':'rename-report',
 'F06-01':'pack-normal','F06-04':'pack-stale-off','F06-05':'pack-tiny-budget','F06-07':'pack-nodecap-1',
 'F06-08':'pack-invalid---max-bytes','F06-12':'path-alias-probes.json',
 'F07-01':'empty-map','F07-04':'map-missing-focus','F07-06':'map-negative-budget',
 'F08-04':'invalid-import-scip','F09-02':'provider-required-missing','F09-12':'real-cbm.log',
 'F10-05':'missing-receipt','F11-04':'invalid-revision','F11-05':'single-commit-default',
 'F12-01':'mcp-stdio.json','F12-02':'mcp-stdio.json','F12-03':'mcp-stdio.json','F12-11':'pack-nodecap-1',
 'F13-01':'corrupt-db-doctor','F13-05':'notes-preserved','F13-07':'maintenance-dry-run',
 'F14-01':'watch-stopped-status','F15-01':'bundle-facts','F15-07':'architecture-missing-flow',
 'F15-09':'export-graphml','F15-10':'export-obsidian'
}
