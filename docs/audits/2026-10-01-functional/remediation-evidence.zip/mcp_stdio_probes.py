import asyncio
import json
import os
from pathlib import Path
import sys

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

HERE = Path(__file__).resolve().parent
ROOT = HERE / 'probe-repo'
RESULTS = []

async def probe(profile):
    params = StdioServerParameters(command=sys.executable,
        args=['-m','sot_graph.cli','--root',str(ROOT),'mcp','--profile',profile],
        env=dict(os.environ, PYTHONPATH=str(Path(os.environ.get('SOT_AUDIT_SOURCE', Path.cwd() / 'src')).resolve()),
                 SOT_EXTRACTOR='builtin', SOT_JIT_MODE='blocking', SOT_ENGINE_BOOTSTRAP='off'))
    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            init=await session.initialize()
            listed=await session.list_tools()
            names={t.name for t in listed.tools}
            r={'profile':profile,'version':init.serverInfo.version,'tools':sorted(names)}
            assert init.serverInfo.version=='0.3.8'
            assert 'sot_search' in names
            assert ('sot_reconcile' in names)==(profile=='ops')
            search=await session.call_tool('sot_search',{'query':'normalize'})
            assert not search.isError
            r['search']=search.model_dump(mode='json')
            pack=await session.call_tool('sot_pack',{'target':'normalize','max_nodes':1})
            assert not pack.isError
            r['pack_nodecap']=pack.model_dump(mode='json')
            negative=await session.call_tool('sot_pack',{'target':'normalize','max_tokens':-1})
            assert negative.isError
            r['negative_budget']=negative.model_dump(mode='json')
            if profile!='ops':
                denied=await session.call_tool('sot_reconcile',{})
                assert denied.isError
                r['denied_write']=denied.model_dump(mode='json')
            else:
                rec=await session.call_tool('sot_reconcile',{})
                assert not rec.isError
                r['reconcile']=rec.model_dump(mode='json')
            r['passed']=True
            RESULTS.append(r)
            print(profile,'PASS','tools',len(names),flush=True)

async def main():
    for profile in ['core','full','ops']:
        try:
            await asyncio.wait_for(probe(profile),45)
        except Exception as e:
            RESULTS.append({'profile':profile,'passed':False,'error':repr(e)})
            print(profile,'FAIL',repr(e),flush=True)
    (HERE/'mcp-stdio.json').write_text(json.dumps(RESULTS,ensure_ascii=False,indent=2))

asyncio.run(main())
