import concurrent.futures,json,os,subprocess
from pathlib import Path
root=Path("/Users/giapminh79/code/GitHub/sotgraph")
folder=Path(Path("/tmp/sotgraph-python-matrix-path").read_text().strip())
tests=["tests/test_audit_regressions.py","tests/test_cli_smoke.py","tests/test_cli_provider_wiring.py","tests/test_engine_admin.py"]
def run(version):
 venv=(root/".venv") if version=="3.12" else (folder/("venv-"+version))
 env=dict(os.environ,SOT_TEST_SETUPTOOLS_PATH="/Users/giapminh79/.cache/uv/archive-v0/AewSJAxZ1MLErdKblu9rm")
 with (folder/("final-cli-"+version+".log")).open("w") as log:
  result=subprocess.run([str(venv/"bin/python"),"-m","pytest",*tests,"-q","-ra","-o","addopts=","--junitxml="+str(folder/("final-cli-"+version+".xml"))],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 return {"version":version,"exit":result.returncode}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 results=list(pool.map(run,["3.10","3.11","3.12","3.13","3.14"]))
(folder/"final-cli-results.json").write_text(json.dumps(results,indent=2))
print(json.dumps(results),flush=True)
raise SystemExit(any(x["exit"] for x in results))
