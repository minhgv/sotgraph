import json,os,subprocess,sys,time
from pathlib import Path
root=Path("/Users/giapminh79/code/GitHub/sotgraph")
folder=Path("/tmp/sotgraph-python-matrix-path").read_text().strip()
folder=Path(folder)
version=sys.argv[1]
install=next((folder/"pythons").glob("cpython-"+version+".*-macos-aarch64-none"))
interpreter=install/"bin"/("python"+version)
venv=folder/("venv-"+version)
env=dict(os.environ,UV_PYTHON_INSTALL_DIR=str(folder/"pythons"),UV_PROJECT_ENVIRONMENT=str(venv),SOT_TEST_SETUPTOOLS_PATH="/Users/giapminh79/.cache/uv/archive-v0/AewSJAxZ1MLErdKblu9rm")
start=time.monotonic()
with (folder/("setup-"+version+".log")).open("w") as log:
 setup=subprocess.run(["uv","sync","--locked","--all-extras","--dev","--python",str(interpreter)],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
if setup.returncode:
 print(json.dumps({"version":version,"stage":"setup","exit":setup.returncode}),flush=True)
 raise SystemExit(setup.returncode)
if "--setup-only" in sys.argv:
 print(json.dumps({"version":version,"stage":"setup","exit":0}),flush=True)
 raise SystemExit(0)
with (folder/("pytest-"+version+".log")).open("w") as log:
 command=[str(venv/"bin/python"),"-m","pytest","tests/","evaluation/tests/","-q","-ra","-o","addopts=","--junitxml="+str(folder/("pytest-"+version+".xml"))]
 proc=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
result={"version":version,"interpreter":str(interpreter),"stage":"pytest","exit":proc.returncode,"elapsed_s":round(time.monotonic()-start,2)}
(folder/("result-"+version+".json")).write_text(json.dumps(result,indent=2))
print(json.dumps(result),flush=True)
raise SystemExit(proc.returncode)
