#!/bin/sh
set -eu
mkdir /workspace
tar -xf /results/minimal-source.tar -C /workspace
cd /workspace
python -m pip install -q --no-index /results/uv-*.whl
uv sync --locked --no-dev
uv pip install --python .venv/bin/python pytest==9.0.2
python --version
uv pip list --python .venv/bin/python
.venv/bin/python -m pytest tests/test_audit_regressions.py -k sqlite_integer_overflow -q -o addopts= --junitxml=/results/minimal-linux-pytest.xml
