from __future__ import annotations

import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
SOURCE = Path(os.environ.get('SOT_AUDIT_SOURCE', Path.cwd() / 'src')).resolve()
ROOT = HERE / 'probe-repo'
ROOT.mkdir(exist_ok=True)
ENV = dict(os.environ, PYTHONPATH=str(SOURCE), SOT_EXTRACTOR='builtin',
           SOT_JIT_MODE='blocking', SOT_ENGINE_BOOTSTRAP='off')
RESULTS = []

def run(name, args, *, root=ROOT, expect=0, json_output=False, check=None, env=None):
    start = time.monotonic()
    try:
        p = subprocess.run([sys.executable, '-m', 'sot_graph.cli', '--root', str(root), *args],
                           capture_output=True, text=True, timeout=35, env=env or ENV)
        record = dict(name=name, args=args, root=str(root), exit=p.returncode,
                      stdout=p.stdout, stderr=p.stderr, seconds=round(time.monotonic()-start, 3))
        record['passed'] = p.returncode == expect if isinstance(expect, int) else p.returncode in expect
        record['graceful'] = 'Traceback (most recent call last)' not in p.stderr
        record['passed'] = record['passed'] and record['graceful']
        if json_output:
            try:
                record['json'] = json.loads(p.stdout)
            except ValueError:
                record['passed'] = False
                record['reason'] = 'stdout is not a JSON document'
        if check and record['passed']:
            try:
                record['passed'] = bool(check(record))
            except Exception as e:
                record['passed'] = False
                record['reason'] = str(e)
    except subprocess.TimeoutExpired as e:
        record = dict(name=name, args=args, root=str(root), passed=False,
                      timeout=True, seconds=round(time.monotonic()-start,3),
                      stdout=str(e.stdout), stderr=str(e.stderr))
    RESULTS.append(record)
    (HERE / 'functional-probes.json').write_text(json.dumps(RESULTS, ensure_ascii=False, indent=2))
    print(name, 'PASS' if record['passed'] else 'FAIL', record.get('exit'), flush=True)
    return record

(ROOT/'app.py').write_text('''from util import normalize

class Base:
    def execute(self):
        return normalize('base')

class Child(Base):
    def execute(self):
        return normalize('child')

def login(token):
    return normalize(token)
''')
(ROOT/'util.py').write_text('''def normalize(value):
    """Normalize login input."""
    return str(value).strip()
''')
(ROOT/'other.py').write_text('def login(value):\n    return value\n')
(ROOT/'nghiệp_vụ.py').write_text('def xử_lý_giao_dịch(value):\n    return value\n')
(ROOT/'tests').mkdir(exist_ok=True)
(ROOT/'tests/test_app.py').write_text('from app import login\n\ndef test_login():\n    assert login(" x ") == "x"\n')
(ROOT/'.gitignore').write_text('.sot/\nreports/\nexports/\n')
for args in [['init','-q'], ['config','user.email','audit@local.invalid'],
             ['config','user.name','Functional audit'], ['add','.'], ['commit','-qm','fixture']]:
    subprocess.run(['git',*args],cwd=ROOT,check=True,capture_output=True)

run('index-initial', ['reconcile','--json'], json_output=True)
run('index-idempotent', ['reconcile','--json'], json_output=True,
    check=lambda r: r['json'].get('updated') == 0)
run('doctor-baseline', ['doctor','--json'], json_output=True,
    check=lambda r:r['json']['ok'])
run('verify-baseline', ['verify','--deep'])
run('search-exact', ['search','normalize','--json'], json_output=True,
    check=lambda r:any(x['symbol']=='normalize' for x in r['json']['results']))
run('search-ambiguous-axes', ['search','login','--json'], json_output=True,
    check=lambda r:any(x['axes']['identity']=='ambiguous' for x in r['json']['results']))
run('search-unicode', ['search','xử_lý_giao_dịch','--json'], json_output=True,
    check=lambda r:len(r['json']['results'])>0)
for q in ['', '   ', '"', "' OR 1=1 --", 'NEAR(', '*', 'a:b', '☃', 'not_a_real_symbol']:
    run('search-robust-'+repr(q), ['search',q,'--json'], json_output=True)
for scope in ['tests','other.py','missing','../','%','_']:
    run('search-scope-'+scope, ['search','login','--scope',scope,'--json'], json_output=True)
for limit in ['0','-1','-999']:
    run('search-invalid-limit-'+limit, ['search','login','-n',limit,'--json'], expect=(1,2))
for threshold in ['nan','inf','-1','2']:
    run('search-invalid-threshold-'+threshold, ['search','login','--threshold',threshold,'--json'], expect=(1,2))
run('explore-callchain', ['explore','normalize','--json'], json_output=True)
run('usages-callchain', ['usages','normalize','--json'], json_output=True)
run('implementations-inheritance', ['implementations','Base'],check=lambda r:'Child' in r['stdout'])
run('rename-report', ['rename','normalize','--to','normalize_new'])
for cmd in ['explore','usages','implementations','rename','pack']:
    args=[cmd,'missing_symbol']
    if cmd=='rename': args+=['--to','new_name']
    run('missing-target-'+cmd,args,expect=(1,2))
for cmd in ['explore','trace']:
    run('negative-depth-'+cmd,[cmd,'normalize','--depth','-1','--json'],expect=(1,2))
run('pack-normal', ['pack','normalize','--tokens','1500','--json'],json_output=True)
run('pack-tiny-budget', ['pack','normalize','--tokens','1','--json'],expect=(1,2),json_output=True)
run('pack-ambiguous', ['pack','login','--json'],expect=(0,2))
for opt in ['--max-hops','--max-nodes','--max-bytes']:
    run('pack-invalid-'+opt,['pack','normalize',opt,'-1','--json'],expect=(1,2))
for cap in ['128','1024']:
    run('map-budget-'+cap,['map','--tokens',cap])
run('map-negative-budget',['map','--tokens','-1'],expect=(1,2))
run('map-missing-focus',['map','--focus','missing'])
run('trace-callchain',['trace','normalize','--json'],json_output=True)
run('scope-receipt',['scope-receipt','normalize','--json'],json_output=True)
run('scope-receipt-missing',['scope-receipt','missing_symbol','--json'],expect=(0,1,2),json_output=True)
run('providers-registry',['providers','list','--format','json'],json_output=True)
run('providers-cross-check',['providers','cross-check','--json'],json_output=True)
run('provider-required-missing',['usages','normalize','--provider','require:scip','--json'],expect=(1,2),json_output=True)
run('watch-stopped-status',['watch','--status'])
run('git-history',['log','-n','2','--json'],json_output=True)
(ROOT/'util.py').write_text((ROOT/'util.py').read_text().replace('.strip()', '.strip().lower()'))
run('verify-drift',['verify','--deep'],expect=(1,2))
run('pack-stale-off',['pack','normalize','--reconcile','off','--json'],expect=(1,2),json_output=True)
run('diff-working-tree',['diff-impact','--working-tree','--json'],json_output=True,
    check=lambda r:'normalize' in json.dumps(r['json']))
run('jit-freshness-recovery',['search','normalize','--reconcile','force','--json'],json_output=True)
(ROOT/'new_module.py').write_text('def newly_added():\n    return 1\n')
run('jit-new-file',['search','newly_added','--json'],json_output=True,
    check=lambda r:any(x['symbol']=='newly_added' for x in r['json']['results']))
(ROOT/'new_module.py').unlink()
run('jit-deleted-file',['search','newly_added','--json'],json_output=True,
    check=lambda r:len(r['json']['results'])==0)
for fmt in ['json','graphrag','graphml','scip','obsidian']:
    run('export-'+fmt,['export','--format',fmt,'--output',str(ROOT/'exports'/fmt)])
run('bundle-facts',['bundle','--output',str(ROOT/'reports/facts'),'--json'],json_output=True)
run('architecture-html',['arch','--output',str(ROOT/'reports/architecture.html')])
run('architecture-missing-flow',['arch','--flow','missing_symbol','--output',str(ROOT/'reports/missing.html')],expect=2,
    check=lambda r:not (ROOT/'reports/missing.html').exists())
run('notes-insert',['insert','--title','Durable audit note','--body','Preserved across reset','--keywords','audit'])
run('maintenance-dry-run',['clean','--all','--dry-run','--json'],json_output=True)
run('maintenance-reset',['clean','--all','--yes','--json'],json_output=True)
conn=sqlite3.connect(ROOT/'.sot/sot.db')
notes=conn.execute("SELECT count(*) FROM graph_nodes WHERE kind='note'").fetchone()[0]
conn.close()
RESULTS.append(dict(name='notes-preserved',passed=notes==1,notes=notes))
run('maintenance-vacuum',['vacuum','--json'],json_output=True)
run('rebuild-after-clean',['reconcile','--json'],json_output=True)
run('setup-workspace-omp',['setup','--harness','omp','--workspace-only'])
run('setup-idempotent',['setup','--harness','omp','--workspace-only'])
for n,config in [('invalid-toml','extractor = [\n'), ('invalid-type','allow_external = "banana"\n')]:
    malformed=HERE/n
    (malformed/'.sot').mkdir(parents=True,exist_ok=True)
    (malformed/'.sot/config.toml').write_text(config)
    run('config-'+n,['reconcile','--json'],root=malformed,expect=(1,2),json_output=True)
corrupt=HERE/'corrupt-db'
(corrupt/'.sot').mkdir(parents=True,exist_ok=True)
(corrupt/'.sot/sot.db').write_bytes(b'not a sqlite database')
run('corrupt-db-doctor',['doctor','--json'],root=corrupt,expect=(1,2),json_output=True)
empty=HERE/'empty-repo'
empty.mkdir(exist_ok=True)
run('empty-reconcile',['reconcile','--json'],root=empty,json_output=True)
run('empty-search',['search','normalize','--json'],root=empty,json_output=True)
run('empty-map',['map'],root=empty)
run('empty-no-git-diff',['diff-impact','--json'],root=empty,expect=(1,2),json_output=True)
(HERE/'functional-probes.json').write_text(json.dumps(RESULTS,ensure_ascii=False,indent=2))
print('TOTAL',len(RESULTS),'PASS',sum(x['passed'] for x in RESULTS),'FAIL',sum(not x['passed'] for x in RESULTS))
